globalVariables(c(".", "gutenberg_id", "language", "has_text",
                  "gutenberg_metadata", "gutenberg_languages", "number", "total",
                  "title", "gutenberg_author_id", "total_languages"))
